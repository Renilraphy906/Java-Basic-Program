package com.aitrich.yellowpages;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		/*
		 * 
		 * ------Original Yellow Pages-----
		 * 
		 * 
		 * */
		
		
		
		YellowPages a = new YellowPages();
		
		a.printingCompany();
		System.out.println();
		
		a.checkCompany();
		System.out.println();
		
		a.checkFirstLetter();
		System.out.println();
		
		a.printingEmployee();
		
		
		

		/*
		 * 
		 * ----Exception Handling-----
		 * 
		 * 
		 * */
		
		
		
		System.out.println();
		System.out.println("Arithmetic Exception Example");
		try
		{
			a.arithmeticCheck();
		} catch(ArithmeticException e){
			
			System.out.println(e);
		}
		
		System.out.println();
		System.out.println("Array Index Out Of Bounds Exception Example");
		try
		{
			a.arrayCheck();
		} catch(ArrayIndexOutOfBoundsException e){
			
			System.out.println(e);
		}
		
		System.out.println();
		System.out.println("Class Cast Exception Example");
		try
		{
			a.classcastCheck();
		} catch(ClassCastException e){
			
			System.out.println(e);
		}
		
		System.out.println();
		System.out.println("Illegal Argument Exception Example");
		try
		{
			a.illegalargumentCheck(500);
		} catch(IllegalArgumentException e){
			
			System.out.println(e);
		}
		
//		System.out.println();
//		System.out.println("Null Pointer Exception Example");
//		try
//		{
//			YellowPages a = null;;
//			a.nullpointCheck();
//			
//		} catch(NullPointerException e){
//			
//			System.out.println(e);
//		}
		
		System.out.println();
		System.out.println("Number Format Exception Example");
		try
		{
			a.numberformatCheck();
		} catch(NumberFormatException e){
			
			System.out.println(e);
		}
	}

}
