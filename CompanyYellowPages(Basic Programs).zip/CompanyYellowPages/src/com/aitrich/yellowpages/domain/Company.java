package com.aitrich.yellowpages.domain;

public class Company {
	
	private int companyid;
	private String companyname;
	City city;
	private long companyphone;
	private String companyemail;
	private String companyweb;
	
	public Company()
	{
		this.companyid= 0;
		this.companyname= null;
		this.city = null;
		this.companyphone= 0;
		this.companyemail= null;
		this.companyweb= null;
	}
	
	public Company(int companyid, String companyname,City city, long companyphone, String companyemail, String companyweb)
	{
		this.companyid = companyid;
		this.companyname = companyname;
		this.city = city;
		this.companyphone = companyphone;
		this.companyemail = companyemail;
		this.companyweb = companyweb;
		
	}
	
	public void setCompanyId(int companyid)
	{
		this.companyid = companyid;
	}
	
	public int getCompanyId()
	{
		return this.companyid;
	}
	
	public void setCompanyName(String companyname)
	{
		this.companyname = companyname;
		
	}
	
	public String getCompanyName()
	{
		return this.companyname;
	}
	
	public void setCity(City city)
	{
		this.city = city;
		
	}
	
	public City getCity()
	{
		return this.city;
	}
	
	public void setCompanyPhone(long companyphone)
	{
		this.companyphone = companyphone;
		
	}
	
	public long getCompanyPhone()
	{
		return this.companyphone;
	}
	
	public void setCompanyEmail(String companyemail)
	{
		this.companyemail = companyemail;
		
	}
	
	public String getComapnyEmail()
	{
		return this.companyemail;
	}
	
	public void setCompanyWeb(String companyweb)
	{
		this.companyweb = companyweb;
		
	}
	
	public String getComapnyWeb()
	{
		return this.companyweb;
	}

	@Override
	public String toString() {
		return "Company [companyid=" + companyid + ", companyname=" + companyname + ", city=" + city + ", companyphone="
				+ companyphone + ", companyemail=" + companyemail + ", companyweb=" + companyweb + "]";
	}	
	
}
