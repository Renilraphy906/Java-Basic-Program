package com.aitrich.yellowpages.domain;

/**
 * @author Renil
 *
 */
/**
 * @author Renil
 *
 */
public class Employee {
	
	private int employeeid;
	private String employeename;
	City city;
	private String employeedesignation;
	private String employeegender;
	private long employeephone;
	Company company;
	
	public Employee()
	{
		this.employeeid = 0;
		this.employeename = null;
		this.city = null;
		this.employeedesignation = null;
		this.employeegender = null;
		this.employeephone = 0;
		this.company = null;
	}
	
	public Employee(int employeeid, String employeename, String employeedesignation,City city,  String employeegender, long employeephone, Company company)
	{
		this.employeeid = employeeid;
		this.employeename = employeename;
		this.city = city;
		this.employeedesignation = employeedesignation;
		this.employeegender = employeegender;
		this.employeephone = employeephone;
		this.company = company;
	}
	
	public void setEmployeeId(int employeeid)
	{
		this.employeeid = employeeid;
	}
	
	public int getEmployeeId()
	{
		return employeeid;
	}
	
	public void setEmployeeName(String employeename)
	{
		this.employeename = employeename;
	}
	
	public String getEmployeeName()
	{
		return employeename;
	}
	
	public void setCity(City city)
	{
		this.city = city;
	}
	
	public City getCity()
	{
		return city;
	}
	
	public void setEmployeeDesignation(String employeedes)
	{
		this.employeedesignation = employeedes;
	}
	
	public String getEmployeeDesignation()
	{
		return employeedesignation;
	}
	
	public void setEmployeegender(String employeegender)
	{
		this.employeegender = employeegender;
	}
	
	public String getEmployeeGender()
	{
		return employeegender;
	}
	
	public void setEmployeePhone(long employeepho)
	{
		this.employeephone = employeepho;
	}
	
	public long getEmployeePhone()
	{
		return employeephone;
	}
	
	public void setCompany(Company company)
	{
		this.company = company;
	}
	
	public Company getCompany()
	{
		return company;
	}

	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", employeename=" + employeename + ", city=" + city
				+ ", employeedesignation=" + employeedesignation + ", employeegender=" + employeegender
				+ ", employeephone=" + employeephone + ", company=" + company + "]";
	}
	
}
