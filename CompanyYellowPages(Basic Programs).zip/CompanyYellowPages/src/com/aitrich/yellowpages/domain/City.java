package com.aitrich.yellowpages.domain;

public enum City {
	
	Kutteneloor,Irinjalakuda,Ponnani,Nadathara,Vadakancheri

}
