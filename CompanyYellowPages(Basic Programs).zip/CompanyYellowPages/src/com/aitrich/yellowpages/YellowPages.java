package com.aitrich.yellowpages;

import com.aitrich.yellowpages.domain.City;
import com.aitrich.yellowpages.domain.Company;
import com.aitrich.yellowpages.domain.Employee;

public class YellowPages {
	
	//----Origial Project----
	
	public Company[] companyDetails()
	{	
		Company[] com = new Company[5];
		
		Company com1 = new Company(1,"Aitrich",City.Nadathara,36585365,"aitrich@gmail.com","aitrich.com");
		Company com2 = new Company(2,"TCS",City.Kutteneloor,949598899,"tcs@gmail.com","tcs.com");
		Company com3 = new Company(3,"Wipro",City.Ponnani,949595679,"wipro@gmail.com","wipro.com");
		Company com4 = new Company(4,"Johnsys",City.Vadakancheri,949597897,"johnsys@gmail.com","johnsys.com");
		Company com5 = new Company(5,"Infox",City.Nadathara,949234567,"infox@gmail.com","infox.com");
		
		com[0]=com1;
		com[1]=com2;
		com[2]=com3;
		com[3]=com4;
		com[4]=com5;
		
		return com;
		
	}
	
	public Employee[] employeeDetails()
	{
		YellowPages a=new YellowPages();
		Company[] b=a.companyDetails();
		
		Employee[] emp = new Employee[5];
		
		Employee emp1 = new Employee(101,"Ramesh","Supervisor",City.Irinjalakuda,"Male",98545656,b[0]);
		Employee emp2 = new Employee(102,"Vedhika","Asst. Supervisor",City.Kutteneloor,"Female",974433,b[1]);
		Employee emp3 = new Employee(103,"Manoj","Developer",City.Ponnani,"Male",934344,b[2]);
		Employee emp4 = new Employee(104,"Sumi","Tester",City.Vadakancheri,"Female",94534,b[3]);
		Employee emp5 = new Employee(101,"Nikhil","Implimentor",City.Nadathara,"Male",9484,b[4]);
		
		emp[0] = emp1;
		emp[1] = emp2;
		emp[2] = emp3;
		emp[3] = emp4;
		emp[4] = emp5;
		
		return emp;
		
	}
	
	public void checkCompany()
	{
		YellowPages b=new YellowPages();
		Company[] a = b.companyDetails();
		int flag = 0;
		String s = "Logistics";
		
		for(Company n : a)
		{
			if(s.equals(n.getCompanyName()))
			{
				flag = 0;
				System.out.println(s+" is existing Company!!!!!");
				break;
			}
			else
			{
				flag=1;	
			}		
		}
		if(flag==1)
		{
			System.out.println();
			System.out.println("Please enter the "+s+" company details.....");
		}
	}
	
	public void checkFirstLetter()
	{
		int flag=0;
		char e = 'I';
		
		YellowPages a=new YellowPages();
		Company[] b=a.companyDetails();
		
		for(Company n : b)
		{
			String s =n.getCompanyName();
			char c=s.charAt(0);
			if(e == c)
			{
				flag=0;
				System.out.println(s+" starts with letter "+e+" .");
				break;
			}
			else
			{
				flag=1;
			}
			
		}
		if(flag == 1)
		{
			System.out.println("There is no company which starts with letter"+e+" .");
		}
	}
	
	public void printingCompany()
	{
		YellowPages a=new YellowPages();
		Company[] b=a.companyDetails();
		
		for(Company n : b)
		{
			System.out.println(n);
		}
	}
	
	public void printingEmployee()
	{
		YellowPages a=new YellowPages();
		Employee[] c=a.employeeDetails();
		
		for(Employee n : c)
		{
			System.out.println(n);
		}
	}
	
	//-----Exception Methods----
	
	

	//-------ArithmeticException----
	
	public void arithmeticCheck()
	{
		Company a=new Company();
		a.setCompanyId(3);
		int b=a.getCompanyId();
		int c=b/0;
		System.out.println(c);
	}
	
	//-----ArrayIndexOutOfBoundsException------
	public void arrayCheck()
	{
		YellowPages a=new YellowPages();
		Company[] b=a.companyDetails();
		
		Company[] c=new Company[5];
		//--Check Array length--- :- int j=b.length;
		
		for(int i=0;i<=5;i++)
		{
			c[i]=b[i];
		}
	}
	
	//---------ClassCastException-----------
	public void classcastCheck()
	{
		Integer in = new Integer(1);
		Object obj=in;
		Company c = (Company) obj;
		System.out.println(c);
				
	}
	
	//---------IllegalArgumentException-----------
		public void illegalargumentCheck(int a)throws IllegalArgumentException
		{
			int salary = a;
			if(salary<1000)
				throw new IllegalArgumentException("Minimum salary not reached  "+salary+" not reached to 1000");			
		}
		
		//---------NullPointerException-----------
		public void nullpointCheck()
		{
			
					
		}
		
		//---------NumberFormatException-----------
		public void numberformatCheck()
		{
			
				String s = "Things";
				int a = Integer.parseInt(s);
				System.out.println(a);
			
		}
			

}
